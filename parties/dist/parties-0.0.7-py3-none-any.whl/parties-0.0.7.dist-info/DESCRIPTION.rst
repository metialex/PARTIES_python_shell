A python shell for parties cfd code

